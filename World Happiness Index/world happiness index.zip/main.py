import os
import sys
from all_tasks import get_top_countries_by_year, top_3_Countries_with_most_first_positions, find_country_rank, list_countries, countries_with_index_above, group_countries_by_rank_ranges, countries_with_consecutive_lower_ranks, country_details

def read_data(file_path):
    if not os.path.isfile(file_path):  # check if the file is available or not
        print("File not found.")
        sys.exit()
    data = [] # we will store our data in list 
    with open(file_path, 'r') as file:   # open file in read mode
        for line in file: # iterate through each line
            row = line.strip().split(',')  # split the line at comma
            data.append(row) # append each row in the data list
    return data
    # in above code we opened file in read mode and store it as lists within list. Each list represent a row

def select_task(file_path):
    data = read_data(file_path)
    instructions = """
        Please Select from the menu to perform specific operation
        1. Top 10 happiest countries or least happiest
        2. top 3 countries that have most first positions from top and bottom
        3. Specific country with increasing its rank or decreasing its rank over specific period
        4. find list of countries
        5. countries with or above specific index value
        6. group contries contries by rank
        7. countries_with_consecutive_lower_ranks over specific period
        8. specific country details
    """
    print(instructions)
    choice = int(input("Please select 1 to 8 number to perform operations: "))
    header = data[0]
    data_ = data[1:]
    if choice==1:
        specific_year = input("Enter year: ")
        top_from_bottom = True if input("select top_from_bottom value(True/False)")=="True" else False
        top_count=int(input("Enter top count: "))
        top_countries_data = get_top_countries_by_year(data_, specific_year=specific_year, top_from_bottom=top_from_bottom, top_count=top_count, print_all=False)
        top_countries_data
    elif choice==2:
        top_from_bottom = True if input("select top_from_bottom value(True/False)")=="True" else False
        # top_count=int(input("Enter top count: "))
        top_countries_data = top_3_Countries_with_most_first_positions(data_, top_from_bottom=top_from_bottom, top_count=3)
        print(top_countries_data)
    elif choice==3:
        country = input("Enter country name(that are in list): ")
        period = int(input("Enter period value(int 1 to 10): "))
        find_country_rank(data_, country, period)
    elif choice==4:
        dsc = True if input("descending order?(True/False): ")=="True" else False
        print(list_countries(data_, dsc=dsc))
    elif choice==5:
        index_threshold = float(input("Enter threshold value(float): "))
        result_countries = countries_with_index_above(data_, index_threshold)
        for country, index in result_countries:
            print(f"{country}: {index}")
    elif choice==6:
        rank_groups = group_countries_by_rank_ranges(data_)
        # Print the countries in each rank range for the last 5 years
        for rank_range, countries in rank_groups.items():
            if countries:  # Display only non-empty rank ranges
                print(f"Rank Range {rank_range}: {countries}")
    elif choice==7:
        consecutive_years = int(input("Enter the number of consective years: "))
        countries_with_consecutive_lower = countries_with_consecutive_lower_ranks(data_, consecutive_years)

        print(f"Countries with at least {consecutive_years} consecutive years of lower ranks: {countries_with_consecutive_lower}")
    elif choice==8:
        country_name = input("Enter Country name: ")
        details = country_details(data_, country_name)
        if details:
            print("Country Details:")
            for key, value in details.items():
                print(f"{key}: {value}")
    else:
        print("Please select a valid choice!!")


if __name__=="__main__":
    file_path = 'world_happiness_index_2013_2023.csv'
    select_task(file_path)